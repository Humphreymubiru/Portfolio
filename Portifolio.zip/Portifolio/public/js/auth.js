document.addEventListener('DOMContentLoaded', () => {
    // DOM Elements
    const loginForm = document.getElementById('loginForm');
    const registerForm = document.getElementById('registerForm');
    const showRegisterBtn = document.getElementById('showRegister');
    const showLoginBtn = document.getElementById('showLogin');
    const loginBox = document.getElementById('loginBox');
    const registerBox = document.getElementById('registerBox');
    const togglePasswordBtns = document.querySelectorAll('.toggle-password');

    // API URL - Use window.location.origin for production or fallback to localhost
    const API_URL = window.location.origin === 'http://localhost:3000' 
        ? 'http://localhost:3000/api'
        : '/api';

    // ... rest of the existing code ...
}); 