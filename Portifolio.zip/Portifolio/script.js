document.addEventListener('DOMContentLoaded', () => {
    console.log('DOM Content Loaded');
    
    // Check authentication
    const token = localStorage.getItem('token') || sessionStorage.getItem('token');
    if (!token) {
        window.location.href = 'login.html';
        return;
    }

    // Logout functionality
    const logoutBtn = document.getElementById('logoutBtn');
    if (logoutBtn) {
        logoutBtn.addEventListener('click', (e) => {
            e.preventDefault();
            localStorage.removeItem('token');
            localStorage.removeItem('user');
            sessionStorage.removeItem('token');
            sessionStorage.removeItem('user');
            window.location.href = 'login.html';
        });
    }
    
    // Theme Toggle
    const themeToggle = document.querySelector('.theme-toggle');
    if (!themeToggle) {
        console.error('Theme toggle button not found');
        return;
    }
    
    const body = document.body;
    const sunIcon = themeToggle.querySelector('i.sun');
    const moonIcon = themeToggle.querySelector('i.moon');
    
    if (!sunIcon || !moonIcon) {
        console.error('Theme icons not found');
        return;
    }

    console.log('Theme toggle elements found');

    // Check for saved user preference, if any, and apply it
    const currentTheme = localStorage.getItem('theme') || 'dark';
    body.classList.toggle('light-mode', currentTheme === 'light');
    sunIcon.classList.toggle('active', currentTheme === 'light');
    moonIcon.classList.toggle('active', currentTheme !== 'light');

    console.log('Theme applied:', currentTheme);

    // Toggle theme on button click
    themeToggle.addEventListener('click', () => {
        body.classList.toggle('light-mode');
        const isLightMode = body.classList.contains('light-mode');

        // Save the user's preference in local storage
        localStorage.setItem('theme', isLightMode ? 'light' : 'dark');

        // Update the button icons with animation
        if (isLightMode) {
            moonIcon.classList.remove('active');
            sunIcon.classList.add('active');
        } else {
            sunIcon.classList.remove('active');
            moonIcon.classList.add('active');
        }
    });

    // Enhanced Smooth Scrolling
    const navLinks = document.querySelectorAll('.nav-link');
    const sections = document.querySelectorAll('section');
    const headerHeight = document.querySelector('.header').offsetHeight;

    // Function to scroll to section
    function scrollToSection(targetId) {
        const targetSection = document.getElementById(targetId);
        if (targetSection) {
            const targetPosition = targetSection.offsetTop - headerHeight;
            window.scrollTo({
                top: targetPosition,
                behavior: 'smooth'
            });
        }
    }

    // Add click event listeners to navigation links
    navLinks.forEach(link => {
        link.addEventListener('click', (e) => {
            e.preventDefault();
            const targetId = link.getAttribute('href').slice(1);
            scrollToSection(targetId);
            
            // Update active state
            navLinks.forEach(l => l.classList.remove('active'));
            link.classList.add('active');

            // Close mobile menu if open
            const navList = document.querySelector('.nav-list');
            const mobileMenuToggle = document.querySelector('.mobile-menu-toggle');
            if (navList.classList.contains('active')) {
                navList.classList.remove('active');
                mobileMenuToggle.classList.remove('active');
                body.classList.remove('menu-open');
            }
        });
    });

    // Mobile menu toggle
    const mobileMenuToggle = document.querySelector('.mobile-menu-toggle');
    const navList = document.querySelector('.nav-list');

    mobileMenuToggle.addEventListener('click', () => {
        mobileMenuToggle.classList.toggle('active');
        navList.classList.toggle('active');
        body.classList.toggle('menu-open');
    });

    // Close mobile menu when clicking outside
    document.addEventListener('click', (e) => {
        if (!navList.contains(e.target) && !mobileMenuToggle.contains(e.target)) {
            navList.classList.remove('active');
            mobileMenuToggle.classList.remove('active');
            body.classList.remove('menu-open');
        }
    });

    // Intersection Observer for section visibility
    const sectionObserverOptions = {
        threshold: 0.2,
        rootMargin: `-${headerHeight}px 0px 0px 0px`
    };

    const sectionObserver = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                // Add visible class for animation
                entry.target.classList.add('visible');
                
                // Update active navigation link
                const sectionId = entry.target.getAttribute('id');
                navLinks.forEach(link => {
                    link.classList.remove('active');
                    if (link.getAttribute('href').slice(1) === sectionId) {
                        link.classList.add('active');
                    }
                });
                
                sectionObserver.unobserve(entry.target);
            }
        });
    }, sectionObserverOptions);

    // Observe all sections
    sections.forEach(section => {
        sectionObserver.observe(section);
    });

    // Handle scroll events for active section highlighting
    let isScrolling = false;
    window.addEventListener('scroll', () => {
        if (!isScrolling) {
            const scrollPosition = window.scrollY + headerHeight;
            
            sections.forEach(section => {
                const sectionTop = section.offsetTop;
                const sectionHeight = section.clientHeight;
                
                if (scrollPosition >= sectionTop && scrollPosition < sectionTop + sectionHeight) {
                    const sectionId = section.getAttribute('id');
                    navLinks.forEach(link => {
                        link.classList.remove('active');
                        if (link.getAttribute('href').slice(1) === sectionId) {
                            link.classList.add('active');
                        }
                    });
                }
            });
        }
    });

    // Enhanced Contact Form Handling
    const contactForm = document.getElementById('contactForm');
    if (contactForm) {
        const formGroups = contactForm.querySelectorAll('.form-group');
        
        // Add real-time validation
        formGroups.forEach(group => {
            const input = group.querySelector('input, textarea');
            if (input) {
                input.addEventListener('input', () => {
                    validateField(input);
                });
                
                input.addEventListener('blur', () => {
                    validateField(input);
                });
            }
        });

        contactForm.addEventListener('submit', async (e) => {
            e.preventDefault();
            
            // Validate all fields before submission
            let isValid = true;
            formGroups.forEach(group => {
                const input = group.querySelector('input, textarea');
                if (input && !validateField(input)) {
                    isValid = false;
                }
            });

            if (!isValid) {
                showNotification('Please fill all required fields correctly.', 'error');
                return;
            }

            const formData = new FormData(contactForm);
            const formObject = Object.fromEntries(formData.entries());

            try {
                // Show loading state
                const submitButton = contactForm.querySelector('button[type="submit"]');
                const originalText = submitButton.textContent;
                submitButton.textContent = 'Sending...';
                submitButton.disabled = true;

                // Here you would typically send the form data to your backend
                // For now, we'll simulate an API call
                await new Promise(resolve => setTimeout(resolve, 1500));

                showNotification('Thank you for your message! I will get back to you soon.', 'success');
                contactForm.reset();
            } catch (error) {
                showNotification('There was an error sending your message. Please try again later.', 'error');
                console.error('Form submission error:', error);
            } finally {
                // Reset button state
                const submitButton = contactForm.querySelector('button[type="submit"]');
                submitButton.textContent = originalText;
                submitButton.disabled = false;
            }
        });
    }

    // Form validation helper function
    function validateField(input) {
        const value = input.value.trim();
        const errorElement = input.parentElement.querySelector('.error-message') || 
                           createErrorElement(input.parentElement);

        if (input.required && !value) {
            showError(input, errorElement, 'This field is required');
            return false;
        }

        if (input.type === 'email' && value && !isValidEmail(value)) {
            showError(input, errorElement, 'Please enter a valid email address');
            return false;
        }

        if (input.type === 'tel' && value && !isValidPhone(value)) {
            showError(input, errorElement, 'Please enter a valid phone number');
            return false;
        }

        hideError(input, errorElement);
        return true;
    }

    // Helper functions for form validation
    function createErrorElement(parent) {
        const errorElement = document.createElement('div');
        errorElement.className = 'error-message';
        parent.appendChild(errorElement);
        return errorElement;
    }

    function showError(input, errorElement, message) {
        input.classList.add('error');
        errorElement.textContent = message;
        errorElement.style.display = 'block';
    }

    function hideError(input, errorElement) {
        input.classList.remove('error');
        errorElement.style.display = 'none';
    }

    function isValidEmail(email) {
        return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
    }

    function isValidPhone(phone) {
        return /^\+?[\d\s-]{10,}$/.test(phone);
    }

    // Notification system
    function showNotification(message, type = 'success') {
        const notification = document.createElement('div');
        notification.className = `notification ${type}`;
        notification.textContent = message;
        
        document.body.appendChild(notification);
        
        // Trigger animation
        setTimeout(() => notification.classList.add('show'), 10);
        
        // Remove notification after 5 seconds
        setTimeout(() => {
            notification.classList.remove('show');
            setTimeout(() => notification.remove(), 300);
        }, 5000);
    }

    // Animate skill progress bars on scroll
    const skillBars = document.querySelectorAll('.skill-progress .progress');
    const skillObserverOptions = {
        threshold: 0.5
    };

    const skillObserver = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.style.width = entry.target.getAttribute('data-width') || '0%';
                skillObserver.unobserve(entry.target);
            }
        });
    }, skillObserverOptions);

    skillBars.forEach(bar => {
        const width = bar.style.width;
        bar.style.width = '0';
        bar.setAttribute('data-width', width);
        skillObserver.observe(bar);
    });
});
